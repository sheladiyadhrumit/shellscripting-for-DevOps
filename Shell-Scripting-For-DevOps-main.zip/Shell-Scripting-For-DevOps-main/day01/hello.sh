#!/bin/bash

# This is script for TWS

echo "TWS: Hello Dosto"

echo "Learners: DevOps Wale bhaiya , hum toh comment karenge"

echo "TWS: Toh dosto, like bhi kar do"
